<?php

$app = new \OCA\QNAP\Application();
$app->registerNotifier();
