# QNAP license app for ownCloud
